#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct{
    char author[10];
    char name[20];
    int page;
}BOOKINFO;

void input_struct(BOOKINFO *book){
    fputs("Author : ", stdout);
    gets(book->author);
    fputs("Name : ", stdout);
    gets(book->author);
    fputs("Page : ", stdout);
    scanf("%d", book->author);
}

void print_struct_members(BOOKINFO book){
    printf("Author : %s\n", book.author);
    printf("Name : %s\n", book.name);
    printf("Page : %d\n", book.page);
    puts("");
}

void input_struct(BOOKINFO *book);
void print_struct_members(BOOKINFO book);

int main(void){
    BOOKINFO book;
    input_struct(&book);
    print_struct_members(book);

    return 0;
}
#include "manage.h"
#include <stdlib.h>
// What is difference between allocated and just decration

int main(void){
    BOOKINFO* book[3];

    for(int i=0;i<3;i++){
        book[i] = (BOOKINFO *)malloc(sizeof(BOOKINFO));
    }

    for(int i=0;i<3;i++){
        input_struct(book[i]);
        print_struct_members(*(book[i]));
    }

    for(int i=0;i<3;i++){
        free(book[i]);
    }

    return 0;
}
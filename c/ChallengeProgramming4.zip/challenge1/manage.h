#ifndef _MANAGE__H__
#define _MANAGE__H__

typedef struct{
    char author[10];
    char name[20];
    int page;
}BOOKINFO;

void input_struct(BOOKINFO *book);
void print_struct_members(BOOKINFO book);

#endif


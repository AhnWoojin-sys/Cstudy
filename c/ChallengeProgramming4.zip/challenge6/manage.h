#ifndef __MANAGE_H__
#define __MANAGE_H__

enum{
    INSERT = 1,
    DELETE = 2,
    SEARCH = 3,
    PRINT = 4
};

typedef struct{
    char name[20];
    int age;
}PERSONINFO;

void task(void);

#endif